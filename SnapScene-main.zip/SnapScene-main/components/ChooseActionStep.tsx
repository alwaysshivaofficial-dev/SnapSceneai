import React from 'react';
import { ActionType } from '../types';
import { BackIcon } from './icons/BackIcon';
import { UserIcon } from './icons/UserIcon';
import { UsersIcon } from './icons/UsersIcon';
import { CrownIcon } from './icons/CrownIcon';
import { TrophyIcon } from './icons/TrophyIcon';


interface ChooseActionStepProps {
  imagePreview: string;
  onSelectAction: (type: ActionType) => void;
  onBack: () => void;
  isPremium: boolean;
}

const ActionButton: React.FC<{title: string, isPremiumFeature: boolean, isPremiumUser: boolean, onClick: () => void, children: React.ReactNode}> = ({ title, isPremiumFeature, isPremiumUser, onClick, children}) => {
    return (
        <button
            onClick={onClick}
            className="relative p-4 bg-gray-700 rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-yellow-500 hover:text-black transition-all duration-200 transform hover:-translate-y-1 group"
        >
            {isPremiumFeature && (
                <div className={`absolute -top-2 -right-2 flex items-center gap-1 text-yellow-400 bg-gray-900 px-2 py-0.5 rounded-full ring-2 ring-gray-700 ${!isPremiumUser ? 'text-yellow-400' : 'text-green-400'}`}>
                    <CrownIcon className="w-3 h-3"/>
                    <span className="text-xs font-bold">Premium</span>
                </div>
            )}
            {children}
            <span className="text-md font-bold text-center">{title}</span>
        </button>
    )
}

const ChooseActionStep: React.FC<ChooseActionStepProps> = ({ imagePreview, onSelectAction, onBack, isPremium }) => {
  return (
    <div className="w-full flex flex-col items-center p-4 sm:p-6 bg-gray-800 rounded-2xl shadow-lg animate-fade-in">
      <div className="relative w-full">
        <button
          onClick={onBack}
          className="absolute top-0 left-0 z-10 p-2 bg-gray-900/50 rounded-full hover:bg-gray-900/80 transition-colors"
          aria-label="Go back"
        >
          <BackIcon className="w-6 h-6" />
        </button>
        <img
          src={imagePreview}
          alt="Uploaded preview"
          className="w-full h-auto max-h-60 object-contain rounded-lg"
        />
      </div>

      <p className="mt-6 text-xl font-semibold text-gray-200">What would you like to do?</p>
      
      <div className="w-full mt-4">
        <div className="grid grid-cols-2 gap-4">
          <ActionButton title="Solo Scene" isPremiumFeature={false} isPremiumUser={isPremium} onClick={() => onSelectAction('solo')}>
             <UserIcon className="w-8 h-8" />
          </ActionButton>
          <ActionButton title="Collab Scene" isPremiumFeature={false} isPremiumUser={isPremium} onClick={() => onSelectAction('collab')}>
             <UsersIcon className="w-8 h-8" />
          </ActionButton>
          <ActionButton title="Group Scene" isPremiumFeature={true} isPremiumUser={isPremium} onClick={() => onSelectAction('group')}>
             <UsersIcon className="w-8 h-8" />
          </ActionButton>
          <ActionButton title="Contest Mode" isPremiumFeature={true} isPremiumUser={isPremium} onClick={() => onSelectAction('contest')}>
             <TrophyIcon className="w-8 h-8" />
          </ActionButton>
        </div>
      </div>
    </div>
  );
};

export default ChooseActionStep;
