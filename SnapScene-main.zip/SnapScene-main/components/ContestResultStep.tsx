import React, { useState } from 'react';
import { DownloadIcon } from './icons/DownloadIcon';
import { RetryIcon } from './icons/RetryIcon';

interface ContestResultStepProps {
  images: string[];
  onReset: () => void;
}

const ContestResultStep: React.FC<ContestResultStepProps> = ({ images, onReset }) => {
    const [selectedImage, setSelectedImage] = useState<string | null>(null);

    const handleDownload = () => {
        if (!selectedImage) return;
        const link = document.createElement('a');
        link.href = selectedImage;
        link.download = 'snapscene-contest-winner.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="w-full flex flex-col items-center p-4 sm:p-6 bg-gray-800 rounded-2xl shadow-lg animate-fade-in">
            <h2 className="text-2xl font-bold text-center">Contest Results</h2>
            <p className="text-gray-300 mt-1 text-center">Tap your favorite to select it!</p>

            <div className="w-full grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
                {images.map((img, index) => (
                    <div
                        key={index}
                        onClick={() => setSelectedImage(img)}
                        className={`relative rounded-lg overflow-hidden cursor-pointer transition-all duration-300 ${selectedImage === img ? 'ring-4 ring-yellow-400 scale-105' : 'ring-2 ring-transparent hover:scale-105'}`}
                    >
                        <img src={img} alt={`Contest variation ${index + 1}`} className="w-full h-full object-cover aspect-square" />
                        {selectedImage === img && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                <span className="text-white font-bold text-lg">Winner!</span>
                            </div>
                        )}
                    </div>
                ))}
            </div>

            <div className="w-full mt-6 flex flex-col gap-4">
                <button
                    onClick={handleDownload}
                    disabled={!selectedImage}
                    className="py-3 px-4 bg-yellow-400 text-gray-900 font-bold rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-300 transition-transform duration-200 transform hover:scale-105 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100"
                >
                    <DownloadIcon className="w-5 h-5" />
                    Download Winner
                </button>
                <button
                    onClick={onReset}
                    className="w-full py-3 px-4 bg-gray-700 text-white font-bold rounded-lg flex items-center justify-center gap-2 hover:bg-gray-600 transition-transform duration-200 transform hover:scale-105"
                >
                    <RetryIcon className="w-5 h-5" />
                    Create Another
                </button>
            </div>
        </div>
    );
}

export default ContestResultStep;
