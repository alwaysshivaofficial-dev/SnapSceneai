import React from 'react';
import { BackIcon } from './icons/BackIcon';
import { TrophyIcon } from './icons/TrophyIcon';

interface ContestStepProps {
  imagePreview: string;
  prompt: string;
  setPrompt: (description: string) => void;
  onGenerate: () => void;
  error: string | null;
  onBack: () => void;
}

const examplePrompts = [
  "as a vintage movie poster",
  "in a vaporwave landscape",
  "at a ramen shop in Tokyo",
  "exploring a coral reef",
  "on a Game of Thrones set",
];

const ContestStep: React.FC<ContestStepProps> = ({
  imagePreview,
  prompt,
  setPrompt,
  onGenerate,
  error,
  onBack
}) => {
  return (
    <div className="w-full flex flex-col items-center p-4 sm:p-6 bg-gray-800 rounded-2xl shadow-lg animate-fade-in">
      <div className="relative w-full">
        <button 
          onClick={onBack} 
          className="absolute top-0 left-0 z-10 p-2 bg-gray-900/50 rounded-full hover:bg-gray-900/80 transition-colors"
          aria-label="Go back"
        >
          <BackIcon className="w-6 h-6" />
        </button>
        <img
          src={imagePreview}
          alt="Your uploaded avatar"
          className="w-full h-auto max-h-40 object-contain rounded-lg"
        />
      </div>
       <div className="text-center mt-4">
            <div className="inline-flex items-center gap-2 text-yellow-400 bg-yellow-900/50 px-3 py-1 rounded-full">
                <TrophyIcon className="w-5 h-5"/>
                <h2 className="text-xl font-bold">Contest Mode</h2>
            </div>
            <p className="text-gray-300 mt-2 text-sm">Enter a prompt and get 3 unique variations. Pick your favorite!</p>
        </div>
      <div className="w-full mt-4">
        <label htmlFor="scene" className="block text-lg font-medium text-gray-200 mb-2">
          Describe the scene:
        </label>
        <textarea
          id="scene"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., 'fighting a dragon in a castle'"
          className="w-full h-24 p-3 bg-gray-700 border-2 border-gray-600 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
        />
      </div>

      <div className="mt-2 w-full">
        <p className="text-sm text-gray-400">Try one:</p>
        <div className="flex flex-wrap gap-2 mt-1">
          {examplePrompts.map((p) => (
            <button
              key={p}
              onClick={() => setPrompt(p)}
              className="px-3 py-1 bg-gray-700 hover:bg-yellow-500 hover:text-black rounded-full text-sm transition-colors"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg w-full text-center">{error}</p>}

      <button
        onClick={onGenerate}
        disabled={!prompt.trim()}
        className="w-full mt-6 py-3 px-6 bg-yellow-400 text-gray-900 font-bold text-lg rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-300 transition-transform duration-200 transform hover:scale-105 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100"
      >
        <TrophyIcon className="w-6 h-6" />
        Generate Variations
      </button>
    </div>
  );
};

export default ContestStep;
