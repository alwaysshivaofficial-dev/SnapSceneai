import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import { BackIcon } from './icons/BackIcon';
import { StarIcon } from './icons/StarIcon';
import { CrownIcon } from './icons/CrownIcon';

interface DescribeSceneStepProps {
  imagePreviews: string[];
  prompt: string;
  setPrompt: (description: string) => void;
  onGenerate: () => void;
  onSurpriseMe: () => void;
  onEnhancePrompt: () => void;
  isEnhancingPrompt: boolean;
  isPremium: boolean;
  removeWatermark: boolean;
  onToggleRemoveWatermark: () => void;
  isHD: boolean;
  onToggleHD: () => void;
  error: string | null;
  onBack: () => void;
}

const SmallSpinner: React.FC = () => (
    <svg className="animate-spin h-4 w-4 text-yellow-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);


const soloExamplePrompts = [
  "sitting in a cozy cafe",
  "DJing at a huge concert",
  "exploring a mysterious cave",
  "on top of Mount Everest",
  "skateboarding in Venice Beach",
];

const multiExamplePrompts = [
    "having coffee together",
    "exploring a city",
    "on a rollercoaster",
    "side-by-side at a concert",
    "starring in a movie poster",
];

const DescribeSceneStep: React.FC<DescribeSceneStepProps> = ({
  imagePreviews,
  prompt,
  setPrompt,
  onGenerate,
  onSurpriseMe,
  onEnhancePrompt,
  isEnhancingPrompt,
  isPremium,
  removeWatermark,
  onToggleRemoveWatermark,
  isHD,
  onToggleHD,
  error,
  onBack
}) => {
  const examplePrompts = imagePreviews.length > 1 ? multiExamplePrompts : soloExamplePrompts;
  
  return (
    <div className="w-full flex flex-col items-center p-4 sm:p-6 bg-gray-800 rounded-2xl shadow-lg animate-fade-in relative">
      <button 
        onClick={onBack} 
        className="absolute top-4 left-4 z-10 p-2 bg-gray-900/50 rounded-full hover:bg-gray-900/80 transition-colors"
        aria-label="Go back"
      >
        <BackIcon className="w-6 h-6" />
      </button>
      <div className="w-full flex justify-center items-end gap-1 h-32">
        {imagePreviews.map((preview, index) => (
            <img
                key={index}
                src={preview}
                alt={`Character ${index + 1}`}
                className="h-full object-contain"
                style={{ transform: `scale(${index === 0 ? 1 : 0.8})`, zIndex: imagePreviews.length - index, position: 'relative', margin: '0 -10px' }}
            />
        ))}
      </div>
      <div className="w-full mt-4">
        <div className="w-full flex justify-between items-center mb-2">
            <label htmlFor="scene" className="block text-lg font-medium text-gray-200">
              Describe the scene:
            </label>
            <div className="flex items-center gap-4">
               <button 
                  onClick={onEnhancePrompt} 
                  disabled={!prompt.trim() || isEnhancingPrompt}
                  className="flex items-center gap-1.5 text-sm text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:text-gray-500 disabled:cursor-not-allowed"
                  aria-label="Enhance prompt with AI"
              >
                  {isEnhancingPrompt 
                      ? <SmallSpinner /> 
                      : <StarIcon className="w-4 h-4" />
                  }
                  {isEnhancingPrompt ? 'Enhancing...' : 'Enhance'}
              </button>
              <button 
                  onClick={onSurpriseMe} 
                  className="hidden sm:flex items-center gap-1 text-sm text-yellow-400 hover:text-yellow-300 font-semibold transition-colors"
                  aria-label="Surprise me with a random prompt"
              >
                  <span role="img" aria-label="paint brush">🎨</span>
                  Surprise me
              </button>
            </div>
        </div>
        <textarea
          id="scene"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., 'on a sunny beach in Bali'"
          className="w-full h-24 p-3 bg-gray-700 border-2 border-gray-600 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
        />
      </div>

      <div className="mt-2 w-full">
        <p className="text-sm text-gray-400">Try one:</p>
        <div className="flex flex-wrap gap-2 mt-1">
          {examplePrompts.map((p) => (
            <button
              key={p}
              onClick={() => setPrompt(p)}
              className="px-3 py-1 bg-gray-700 hover:bg-yellow-500 hover:text-black rounded-full text-sm transition-colors"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg w-full text-center">{error}</p>}
      
      <div className="w-full mt-6 space-y-2">
        <div className="flex items-center justify-between p-3 bg-gray-900/30 rounded-lg">
            <div className="flex items-center gap-2">
                <label htmlFor="hd-toggle" className={`font-medium cursor-pointer select-none ${isPremium ? 'text-gray-200' : 'text-gray-500'}`}>
                    HD Quality
                </label>
                <div className="flex items-center gap-1 text-yellow-400 bg-yellow-900/50 px-2 py-0.5 rounded-full">
                    <CrownIcon className="w-3 h-3"/>
                    <span className="text-xs font-bold">Premium</span>
                </div>
            </div>
            <button
                id="hd-toggle"
                onClick={onToggleHD}
                disabled={!isPremium}
                className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-yellow-400 ${
                    isPremium && isHD ? 'bg-yellow-400' : 'bg-gray-600'
                } ${!isPremium ? 'cursor-not-allowed' : ''}`}
                role="switch"
                aria-checked={isPremium && isHD}
            >
                <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isPremium && isHD ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
        </div>

        <div className="flex items-center justify-between p-3 bg-gray-900/30 rounded-lg">
            <div className="flex items-center gap-2">
                <label htmlFor="watermark-toggle" className={`font-medium cursor-pointer select-none ${isPremium ? 'text-gray-200' : 'text-gray-500'}`}>
                    Remove Watermark
                </label>
                <div className="flex items-center gap-1 text-yellow-400 bg-yellow-900/50 px-2 py-0.5 rounded-full">
                    <CrownIcon className="w-3 h-3"/>
                    <span className="text-xs font-bold">Premium</span>
                </div>
            </div>
            <button
              id="watermark-toggle"
              onClick={onToggleRemoveWatermark}
              className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-yellow-400 ${
                isPremium && removeWatermark ? 'bg-yellow-400' : 'bg-gray-600'
              }`}
              role="switch"
              aria-checked={removeWatermark}
            >
              <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isPremium && removeWatermark ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
        </div>
      </div>


      <button
        onClick={() => onGenerate()}
        disabled={!prompt.trim()}
        className="w-full mt-4 py-3 px-6 bg-yellow-400 text-gray-900 font-bold text-lg rounded-lg flex items-center justify-center hover:bg-yellow-300 transition-transform duration-200 transform hover:scale-105 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100"
      >
        Generate Image
      </button>
    </div>
  );
};

export default DescribeSceneStep;
