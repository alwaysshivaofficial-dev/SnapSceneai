
import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import { BackIcon } from './icons/BackIcon';

interface DescribeStepProps {
  imagePreview: string;
  sceneDescription: string;
  setSceneDescription: (description: string) => void;
  onGenerate: () => void;
  error: string | null;
  onBack: () => void;
}

const examplePrompts = [
  "on a beach in Bali",
  "DJing at a concert",
  "exploring a cave",
  "on top of Mount Everest",
  "in a cozy café",
];

const DescribeStep: React.FC<DescribeStepProps> = ({
  imagePreview,
  sceneDescription,
  setSceneDescription,
  onGenerate,
  error,
  onBack
}) => {
  return (
    <div className="w-full flex flex-col items-center p-4 sm:p-6 bg-gray-800 rounded-2xl shadow-lg animate-fade-in">
      <div className="relative w-full">
        <button 
          onClick={onBack} 
          className="absolute top-0 left-0 z-10 p-2 bg-gray-900/50 rounded-full hover:bg-gray-900/80 transition-colors"
          aria-label="Go back"
        >
          <BackIcon className="w-6 h-6" />
        </button>
        <img
          src={imagePreview}
          alt="Uploaded Bitmoji"
          className="w-full h-auto max-h-60 object-contain rounded-lg"
        />
      </div>
      <div className="w-full mt-4">
        <label htmlFor="scene" className="block text-lg font-medium text-gray-200 mb-2">
          Describe the scene:
        </label>
        <textarea
          id="scene"
          value={sceneDescription}
          onChange={(e) => setSceneDescription(e.target.value)}
          placeholder="e.g., 'on a beach in Bali at sunset'"
          className="w-full h-24 p-3 bg-gray-700 border-2 border-gray-600 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
        />
      </div>

      <div className="mt-2 w-full">
        <p className="text-sm text-gray-400">Try one:</p>
        <div className="flex flex-wrap gap-2 mt-1">
          {examplePrompts.map((prompt) => (
            <button
              key={prompt}
              onClick={() => setSceneDescription(prompt)}
              className="px-3 py-1 bg-gray-700 hover:bg-yellow-500 hover:text-black rounded-full text-sm transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg w-full text-center">{error}</p>}

      <button
        onClick={onGenerate}
        disabled={!sceneDescription.trim()}
        className="w-full mt-6 py-3 px-6 bg-yellow-400 text-gray-900 font-bold text-lg rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-300 transition-transform duration-200 transform hover:scale-105 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100"
      >
        <SparklesIcon className="w-6 h-6" />
        Generate Scene
      </button>
    </div>
  );
};

export default DescribeStep;
