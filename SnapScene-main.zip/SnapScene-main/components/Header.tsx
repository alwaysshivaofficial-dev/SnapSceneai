import React from 'react';
import { AvatarIcon } from './icons/AvatarIcon';

const Header: React.FC = () => {
  return (
    <header className="text-center">
      <div className="inline-flex items-center gap-3">
        <div className="bg-yellow-400 p-2 rounded-lg">
           <AvatarIcon className="w-8 h-8 text-black" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight bg-gradient-to-r from-yellow-300 to-yellow-500 text-transparent bg-clip-text">
          SnapScene
        </h1>
      </div>
      <p className="mt-2 text-md text-gray-300">Stylize and animate your Bitmoji.</p>
    </header>
  );
};

export default Header;