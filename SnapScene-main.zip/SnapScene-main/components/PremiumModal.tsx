import React from 'react';
import { CrownIcon } from './icons/CrownIcon';
import { CheckIcon } from './icons/CheckIcon';
import { CrossIcon } from './icons/CrossIcon';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
}

const FeatureItem: React.FC<{ text: string; free: boolean; premium: boolean; }> = ({ text, free, premium }) => (
    <div className="flex items-center justify-between py-3 border-b border-gray-700/50">
        <span className="text-gray-300">{text}</span>
        <div className="flex items-center gap-12 sm:gap-16">
            {free ? <CheckIcon className="w-6 h-6 text-green-400" /> : <CrossIcon className="w-6 h-6 text-red-400" />}
            {premium ? <CheckIcon className="w-6 h-6 text-green-400" /> : <CrossIcon className="w-6 h-6 text-red-400" />}
        </div>
    </div>
);


const PremiumModal: React.FC<PremiumModalProps> = ({ isOpen, onClose, onUpgrade }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-md p-6 text-center transform transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto bg-yellow-400 w-16 h-16 rounded-full flex items-center justify-center ring-4 ring-yellow-400/30">
            <CrownIcon className="w-10 h-10 text-black" />
        </div>
        <h2 className="text-2xl font-bold mt-4 bg-gradient-to-r from-yellow-300 to-yellow-500 text-transparent bg-clip-text">
            Upgrade to Premium
        </h2>
        <p className="text-gray-300 mt-2">Unlock all features and create without limits.</p>
        
        <div className="text-left mt-6">
            <div className="flex justify-end font-bold text-sm">
                <div className="w-16 sm:w-20 text-center text-gray-400">Free</div>
                <div className="w-16 sm:w-20 text-center text-yellow-400">Premium</div>
            </div>
            <div className="mt-2 space-y-1">
                <FeatureItem text="Solo Scene Generation" free={true} premium={true} />
                <FeatureItem text="Collab Scene (2 total)" free={true} premium={true} />
                <FeatureItem text="Group Scene (up to 4)" free={false} premium={true} />
                <FeatureItem text="Contest Mode Access" free={false} premium={true} />
                <FeatureItem text="Standard Quality" free={true} premium={true} />
                <FeatureItem text="HD Quality Downloads" free={false} premium={true} />
                <FeatureItem text="Watermarked Images" free={true} premium={false} />
            </div>
        </div>

        <button
            onClick={onUpgrade}
            className="w-full mt-8 py-3 px-4 bg-yellow-400 text-gray-900 font-bold rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-300 transition-all duration-200 transform hover:scale-105"
        >
            Upgrade Now - ₹29/mo
        </button>
        <button
            onClick={onClose}
            className="w-full mt-3 text-gray-400 text-sm hover:text-white transition-colors"
        >
            Maybe Later
        </button>
      </div>
    </div>
  );
};

export default PremiumModal;