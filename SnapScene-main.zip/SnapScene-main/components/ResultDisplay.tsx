import React, { useState, useEffect } from 'react';
import { DownloadIcon } from './icons/DownloadIcon';
import { SnapchatIcon } from './icons/SnapchatIcon';
import { ShareGuideModal } from './ShareGuideModal';
import { RetryIcon } from './icons/RetryIcon';

interface ResultDisplayProps {
  isLoading: boolean;
  generatedImage: string | null;
  isHD: boolean;
  onReset: () => void;
}

const loadingMessages = [
    "Painting your scene...",
    "Perfecting the pixels...",
    "Adding some magic...",
    "Warming up the engine...",
    "Almost there...",
];

const LoadingSpinner: React.FC = () => {
    const [message, setMessage] = React.useState(loadingMessages[0]);

    React.useEffect(() => {
        const interval = setInterval(() => {
            setMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-4">
      <svg className="animate-spin -ml-1 mr-3 h-12 w-12 text-yellow-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
      <p className="mt-4 text-lg text-gray-300">{message}</p>
    </div>
  );
};

const ResultDisplay: React.FC<ResultDisplayProps> = ({
  isLoading,
  generatedImage,
  isHD,
  onReset,
}) => {
  const [canShare, setCanShare] = useState(false);
  const [isImageVisible, setIsImageVisible] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  useEffect(() => {
    if (typeof navigator.share === 'function' && typeof navigator.canShare === 'function') {
      const dummyFile = new File([''], 'dummy.png', { type: 'image/png' });
      if (navigator.canShare({ files: [dummyFile] })) {
        setCanShare(true);
      }
    }
  }, []);

  useEffect(() => {
    // Reset visibility when the image changes or is removed to re-trigger animation
    if (!generatedImage) {
      setIsImageVisible(false);
    }
  }, [generatedImage]);

  const handleDownload = () => {
    if (!generatedImage) return;
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = 'snapscene.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      <ShareGuideModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />
      <div className="w-full flex flex-col items-center p-4 sm:p-6 bg-gray-800 rounded-2xl shadow-lg animate-fade-in relative">
        <div className="w-full aspect-square bg-gray-900 rounded-lg overflow-hidden flex items-center justify-center relative">
          {isLoading && <LoadingSpinner />}
          {!isLoading && generatedImage && (
            <>
              {isHD && (
                <div className="absolute top-2 right-2 bg-yellow-400 text-black text-xs font-bold px-2 py-1 rounded-full z-10">
                  HD
                </div>
              )}
              <img
                src={generatedImage}
                alt="Generated Scene"
                onLoad={() => setIsImageVisible(true)}
                className={`w-full h-full object-contain transition-all duration-500 ease-in-out ${isImageVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}
              />
            </>
          )}
        </div>

        {!isLoading && generatedImage && (
           <div className="w-full mt-6 flex flex-col gap-4">
              <div className={`grid ${canShare ? 'grid-cols-2' : 'grid-cols-1'} gap-4`}>
                  <button
                      onClick={handleDownload}
                      className="py-3 px-4 bg-gray-600 text-white font-bold rounded-lg flex items-center justify-center gap-2 hover:bg-gray-500 transition-transform duration-200 transform hover:scale-105"
                  >
                      <DownloadIcon className="w-5 h-5" />
                      Download
                  </button>
                  {canShare && (
                      <button
                          onClick={() => setIsShareModalOpen(true)}
                          className="py-3 px-4 bg-yellow-400 text-gray-900 font-bold rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-300 transition-all duration-200 transform hover:scale-105"
                      >
                          <SnapchatIcon className="w-6 h-6" />
                          Share as Snap
                      </button>
                  )}
              </div>
              <button
                onClick={onReset}
                className="w-full py-3 px-4 bg-gray-700 text-white font-bold rounded-lg flex items-center justify-center gap-2 hover:bg-gray-600 transition-transform duration-200 transform hover:scale-105"
              >
                <RetryIcon className="w-5 h-5" />
                Create Another
              </button>
          </div>
        )}
      </div>
    </>
  );
};

export default ResultDisplay;
