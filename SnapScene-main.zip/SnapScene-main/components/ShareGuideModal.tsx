import React from 'react';
import { SnapchatIcon } from './icons/SnapchatIcon';

interface ShareGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareGuideModal: React.FC<ShareGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const snapchatLensUrl = 'https://www.snapchat.com/lens/4ec5ac5963e94aef8f0267a0b90fa736?share_id=-yqAHIfI04Y&locale=en-US';

  return (
    <div 
      className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-sm p-6 text-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto bg-yellow-400 w-16 h-16 rounded-full flex items-center justify-center">
            <SnapchatIcon className="w-10 h-10 text-black" />
        </div>
        <h2 className="text-2xl font-bold mt-4">Share as a Streak Snap</h2>
        <p className="text-gray-300 mt-2">
            While you can't send this directly for streaks, we've got a clever workaround!
        </p>
        
        <ol className="text-left text-gray-300 mt-4 space-y-3 text-sm px-2">
            <li className="flex items-start gap-3">
                <span className="font-bold text-yellow-400 text-lg">1.</span>
                <span>First, make sure you've <span className="font-bold">downloaded the image</span> to your device.</span>
            </li>
            <li className="flex items-start gap-3">
                <span className="font-bold text-yellow-400 text-lg">2.</span>
                <span>Click to open the <a href={snapchatLensUrl} target="_blank" rel="noopener noreferrer" className="text-yellow-400 underline hover:text-yellow-300">Gallery Lens</a> in Snapchat.</span>
            </li>
            <li className="flex items-start gap-3">
                <span className="font-bold text-yellow-400 text-lg">3.</span>
                <span>Choose your downloaded photo and send to build effortless streaks! 👻</span>
            </li>
        </ol>

        <p className="text-xs text-gray-400 mt-6 italic">
            Don't worry, direct and effortless sharing will be launching shortly!
        </p>

        <a
            href={snapchatLensUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-block mt-4 py-3 px-4 bg-yellow-400 text-gray-900 font-bold rounded-lg text-center hover:bg-yellow-300 transition-all duration-200 transform hover:scale-105"
        >
            Open Snapchat Lens
        </a>
        <button
            onClick={onClose}
            className="w-full mt-3 text-gray-400 text-sm hover:text-white transition-colors"
        >
            Got It
        </button>
      </div>
    </div>
  );
};