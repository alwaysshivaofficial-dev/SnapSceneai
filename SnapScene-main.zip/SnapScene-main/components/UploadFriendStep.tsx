import React, { useCallback, useState } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import { BackIcon } from './icons/BackIcon';
import { CrossIcon } from './icons/CrossIcon';

interface UploadFriendsStepProps {
  onAddFriend: (file: File) => void;
  onRemoveFriend: (index: number) => void;
  friendPreviews: string[];
  maxFriends: number;
  onBack: () => void;
  onDone: () => void;
}

const UploadFriendsStep: React.FC<UploadFriendsStepProps> = ({ onAddFriend, onRemoveFriend, friendPreviews, maxFriends, onBack, onDone }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const friendsCount = friendPreviews.length;
  const canAddMore = friendsCount < maxFriends;

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0] && canAddMore) {
      onAddFriend(event.target.files[0]);
      // Reset file input to allow uploading the same file again
      event.target.value = '';
    }
  };

  const handleClick = () => {
    if (canAddMore) {
      fileInputRef.current?.click();
    }
  };
  
  const handleDragEvents = (e: React.DragEvent<HTMLDivElement>, isEntering: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    if(canAddMore) setIsDragging(isEntering);
  };
  
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    handleDragEvents(e, false);
    if (e.dataTransfer.files && e.dataTransfer.files[0] && canAddMore) {
      onAddFriend(e.dataTransfer.files[0]);
    }
  }, [onAddFriend, canAddMore]);


  return (
    <div className="w-full flex flex-col items-center justify-center p-6 bg-gray-800 rounded-2xl shadow-lg relative animate-fade-in">
      <button 
        onClick={onBack} 
        className="absolute top-4 left-4 z-10 p-2 bg-gray-900/50 rounded-full hover:bg-gray-900/80 transition-colors"
        aria-label="Go back"
      >
        <BackIcon className="w-6 h-6" />
      </button>

      <div
        onClick={handleClick}
        onDragEnter={(e) => handleDragEvents(e, true)}
        onDragLeave={(e) => handleDragEvents(e, false)}
        onDragOver={(e) => handleDragEvents(e, true)}
        onDrop={handleDrop}
        className={`w-full h-48 border-4 border-dashed rounded-xl flex flex-col items-center justify-center transition-all duration-300 ${!canAddMore ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'} ${isDragging ? 'border-yellow-400 bg-gray-700' : 'border-gray-600 hover:border-yellow-500'}`}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="image/png, image/jpeg, image/webp"
          disabled={!canAddMore}
        />
        <UploadIcon className="w-12 h-12 text-gray-400 mb-2" />
        <p className="text-lg font-semibold text-gray-200">
            {canAddMore ? `Add Friend's Bitmoji (${friendsCount}/${maxFriends})` : `Maximum Friends Reached`}
        </p>
        {canAddMore && <p className="text-gray-400 text-sm">Click to browse or drag & drop</p>}
      </div>
      
      {friendsCount > 0 && (
          <div className="w-full mt-4">
              <p className="text-md font-semibold text-gray-300">Friends Added:</p>
              <div className="grid grid-cols-3 gap-2 mt-2">
                  {friendPreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square">
                          <img src={preview} alt={`Friend ${index+1}`} className="w-full h-full object-contain rounded-md bg-gray-700/50" />
                          <button onClick={() => onRemoveFriend(index)} className="absolute -top-1 -right-1 bg-red-500 rounded-full p-0.5 hover:bg-red-400">
                            <CrossIcon className="w-3 h-3 text-white" />
                          </button>
                      </div>
                  ))}
              </div>
          </div>
      )}

      <button
        onClick={onDone}
        disabled={friendsCount === 0}
        className="w-full mt-6 py-3 px-6 bg-yellow-400 text-gray-900 font-bold text-lg rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-300 transition-transform duration-200 transform hover:scale-105 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100"
      >
        Next
      </button>

      <div className="mt-4 p-3 bg-gray-900/50 rounded-lg w-full text-center">
        <p className="text-sm text-yellow-300 font-semibold">Pro Tip:</p>
        <p className="text-xs text-gray-300">Use Bitmojis with transparent backgrounds for the best results!</p>
      </div>
    </div>
  );
};

export default UploadFriendsStep;
