
import React, { useCallback, useState } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import { SnapchatIcon } from './icons/SnapchatIcon';

interface UploadStepProps {
  onImageUpload: (file: File) => void;
  isVerifying: boolean;
  error: string | null;
}

const SmallSpinner: React.FC = () => (
    <svg className="animate-spin h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);


const UploadStep: React.FC<UploadStepProps> = ({ onImageUpload, isVerifying, error }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      onImageUpload(event.target.files[0]);
    }
  };

  const handleClick = () => {
    if (isVerifying) return;
    fileInputRef.current?.click();
  };
  
  const handleDragEvents = (e: React.DragEvent<HTMLDivElement>, isEntering: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    if (isVerifying) return;
    setIsDragging(isEntering);
  };
  
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    handleDragEvents(e, false);
    if (isVerifying) return;
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onImageUpload(e.dataTransfer.files[0]);
    }
  }, [onImageUpload, isVerifying]);


  return (
    <div className="w-full flex flex-col items-center justify-center p-6 bg-gray-800 rounded-2xl shadow-lg">
      <div
        onClick={handleClick}
        onDragEnter={(e) => handleDragEvents(e, true)}
        onDragLeave={(e) => handleDragEvents(e, false)}
        onDragOver={(e) => handleDragEvents(e, true)}
        onDrop={handleDrop}
        className={`w-full h-64 border-4 border-dashed rounded-xl flex flex-col items-center justify-center transition-all duration-300 ${isVerifying ? 'cursor-not-allowed' : 'cursor-pointer'} ${isDragging ? 'border-yellow-400 bg-gray-700' : 'border-gray-600 hover:border-yellow-500'}`}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="image/png, image/jpeg, image/webp"
          disabled={isVerifying}
        />
        {isVerifying ? (
            <>
                <SmallSpinner />
                <p className="text-xl font-semibold text-gray-200 mt-4">Verifying image...</p>
                <p className="text-gray-400">Please wait.</p>
            </>
        ) : (
            <>
                <UploadIcon className="w-16 h-16 text-gray-400 mb-4 transition-transform duration-300 group-hover:scale-110" />
                <p className="text-xl font-semibold text-gray-200">Upload your Bitmoji</p>
                <p className="text-gray-400">Click to browse or drag & drop</p>
            </>
        )}
      </div>

       {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg w-full text-center">{error}</p>}

      <div className="relative my-4 w-full flex items-center justify-center">
        <div className="flex-grow border-t border-gray-600"></div>
        <span className="flex-shrink mx-4 text-gray-500 text-sm">OR</span>
        <div className="flex-grow border-t border-gray-600"></div>
      </div>
      
      <button
        disabled
        className="w-full py-3 px-6 bg-yellow-400 text-gray-900 font-bold text-lg rounded-lg flex items-center justify-center gap-2 transition-transform duration-200 transform disabled:bg-gray-600 disabled:cursor-not-allowed"
      >
        <SnapchatIcon className="w-7 h-7" />
        Continue with Snapchat
      </button>
      <p className="text-xs text-gray-500 mt-2">Coming soon!</p>
    </div>
  );
};

export default UploadStep;