import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import { BackIcon } from './icons/BackIcon';

interface VideoStepProps {
  imagePreview: string;
  prompt: string;
  setPrompt: (description: string) => void;
  aspectRatio: '16:9' | '9:16';
  setAspectRatio: (ratio: '16:9' | '9:16') => void;
  onGenerate: () => void;
  error: string | null;
  onBack: () => void;
}

const examplePrompts = [
  "A gentle, looping bounce animation",
  "Confetti falls from the sky",
  "Subtle pulsing color background",
  "The character gives a thumbs up",
  "A magical shimmer effect",
];

const VideoStep: React.FC<VideoStepProps> = ({
  imagePreview,
  prompt,
  setPrompt,
  aspectRatio,
  setAspectRatio,
  onGenerate,
  error,
  onBack
}) => {
  return (
    <div className="w-full flex flex-col items-center p-4 sm:p-6 bg-gray-800 rounded-2xl shadow-lg animate-fade-in">
      <div className="relative w-full">
        <button 
          onClick={onBack} 
          className="absolute top-0 left-0 z-10 p-2 bg-gray-900/50 rounded-full hover:bg-gray-900/80 transition-colors"
          aria-label="Go back"
        >
          <BackIcon className="w-6 h-6" />
        </button>
        <img
          src={imagePreview}
          alt="Uploaded preview"
          className="w-full h-auto max-h-60 object-contain rounded-lg"
        />
      </div>
      <div className="w-full mt-4">
        <label htmlFor="scene" className="block text-lg font-medium text-gray-200 mb-2">
          Describe the video:
        </label>
        <textarea
          id="scene"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., 'Make the character wink and smile'"
          className="w-full h-24 p-3 bg-gray-700 border-2 border-gray-600 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
        />
      </div>
      
      <div className="mt-4 w-full">
        <p className="text-lg font-medium text-gray-200 mb-2">Aspect Ratio:</p>
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => setAspectRatio('16:9')} className={`py-2 px-4 rounded-lg font-semibold transition-colors ${aspectRatio === '16:9' ? 'bg-yellow-400 text-black' : 'bg-gray-700 hover:bg-gray-600'}`}>
            16:9 Landscape
          </button>
          <button onClick={() => setAspectRatio('9:16')} className={`py-2 px-4 rounded-lg font-semibold transition-colors ${aspectRatio === '9:16' ? 'bg-yellow-400 text-black' : 'bg-gray-700 hover:bg-gray-600'}`}>
            9:16 Portrait
          </button>
        </div>
      </div>


      <div className="mt-4 w-full">
        <p className="text-sm text-gray-400">Try one:</p>
        <div className="flex flex-wrap gap-2 mt-1">
          {examplePrompts.map((p) => (
            <button
              key={p}
              onClick={() => setPrompt(p)}
              className="px-3 py-1 bg-gray-700 hover:bg-yellow-500 hover:text-black rounded-full text-sm transition-colors"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg w-full text-center">{error}</p>}

      <button
        onClick={onGenerate}
        disabled={!prompt.trim()}
        className="w-full mt-6 py-3 px-6 bg-yellow-400 text-gray-900 font-bold text-lg rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-300 transition-transform duration-200 transform hover:scale-105 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100"
      >
        <SparklesIcon className="w-6 h-6" />
        Animate Scene
      </button>
    </div>
  );
};

export default VideoStep;