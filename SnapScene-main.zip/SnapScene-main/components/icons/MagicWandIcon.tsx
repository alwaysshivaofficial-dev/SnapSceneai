import React from 'react';

export const MagicWandIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    {...props}
  >
    <path d="M15 4V2m0 20v-2m5-15h2M2 9h2m15-5l1.5-1.5M4.5 19.5L3 21m0-18l1.5 1.5M19.5 4.5L21 3m-1.5 16.5l-1.5 1.5M9 22V10M4 15h11" />
    <path d="M12 4V2" />
    <path d="M12 22v-2" />
  </svg>
);
