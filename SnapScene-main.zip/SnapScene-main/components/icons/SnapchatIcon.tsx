import React from 'react';

export const SnapchatIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    {...props}
  >
    <path d="M11.5,2C6.81,2,3,5.81,3,10.5a6.5,6.5,0,0,0,1,3.41,1.4,1.4,0,0,1,.13.79V20.4a.9.9,0,0,0,1.35.81l3.56-2.14a.9.9,0,0,1,1,0l3.56,2.14a.9.9,0,0,0,1.35-.81V14.7a1.4,1.4,0,0,1,.13-.79A6.5,6.5,0,0,0,20,10.5C20,5.81,16.19,2,11.5,2Z" />
  </svg>
);