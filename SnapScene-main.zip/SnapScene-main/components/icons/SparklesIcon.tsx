
import React from 'react';

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
    strokeWidth={2}
    {...props}
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M5 3v4M3 5h4M19 3v4M17 5h4M12 3v4M10 5h4M5 21v-4M3 19h4M19 21v-4M17 19h4M12 21v-4M10 19h4M10.875 10.875l-1.75-1.75M14.875 14.875l-1.75-1.75M10.875 14.875l1.75-1.75M14.875 10.875l1.75 1.75"
    />
  </svg>
);
