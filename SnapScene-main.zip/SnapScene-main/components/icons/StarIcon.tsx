import React from 'react';

export const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
    fill="currentColor"
    {...props}
  >
    <path
      fillRule="evenodd"
      d="M10.868 2.884c.321-.662 1.215-.662 1.536 0l1.681 3.462 3.91.569c.728.106 1.02.996.491 1.503l-2.83 2.759.668 3.903c.124.724-.628 1.285-1.28.93l-3.5-1.84-3.5 1.84c-.652.355-1.405-.206-1.28-.93l.668-3.903-2.83-2.759c-.53-.507-.237-1.397.49-1.503l3.91-.569 1.681-3.462z"
      clipRule="evenodd"
    />
  </svg>
);