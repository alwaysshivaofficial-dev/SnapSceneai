import { GoogleGenAI, Modality, Type } from "@google/genai";

const getSceneGenerationInstruction = (characterCount: number, isHD: boolean) => {
  const characterText = characterCount > 1 
    ? "the user-provided character images and place them together" 
    : "the user-provided character image and place it";
  
  const qualityInstruction = isHD 
    ? `\n6. **Quality:** Generate the image in the highest possible definition and detail. Focus on crisp lines and rich textures suitable for a high-resolution display.`
    : '';

  return `You are an expert image generator specializing in cartoon avatar scenes. Your task is to integrate ${characterText} into a new scene based on the user's text prompt.

**Crucial Instructions:**
1.  **Character Integrity:** Preserve the original characters' appearance, including their art style, clothing, facial features, and colors, with 100% accuracy. Do NOT alter, modify, or redraw the characters. They should look exactly as provided.
2.  **Scene Integration:** Place the characters naturally within the described scene. They should look like they belong there, interacting with the environment if appropriate.
3.  **Style Consistency:** The generated background and environment MUST match the clean, vector-art style of the Bitmoji avatars. Use simple shading, vibrant colors, and avoid photorealistic textures or lighting. The final image must be a single, cohesive cartoon scene.
4.  **Focus:** The provided characters must be the primary subject of the final image. Do not add any other characters unless explicitly asked for in the prompt.
5.  **Output:** Generate a single, high-quality image that seamlessly combines the characters and the new scene.` + qualityInstruction;
}

export const verifyIsAvatar = async (base64Image: {data: string, mimeType: string}): Promise<{isAvatar: boolean, reason: string}> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
  const model = 'gemini-2.5-flash';
  const prompt = `Analyze the following image. Is it a single, full-body or upper-body cartoon-style avatar (like a Bitmoji or Memoji) on a simple or transparent background? The character should be the main focus. Do not accept photos of real people, animals, complex scenes, or logos. Respond in JSON format with two keys: "isAvatar" (boolean) and "reason" (a brief explanation in 5-10 words).`;

  try {
    const response = await ai.models.generateContent({
        model,
        contents: {
            parts: [
                { inlineData: { data: base64Image.data, mimeType: base64Image.mimeType } },
                { text: prompt },
            ]
        },
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    isAvatar: { type: Type.BOOLEAN, description: 'Whether the image is a valid avatar.' },
                    reason: { type: Type.STRING, description: 'A brief reason for the decision.' }
                },
                required: ['isAvatar', 'reason']
            }
        }
    });
    
    const jsonStr = response.text.trim();
    // In case the response is wrapped in markdown
    const cleanedJsonStr = jsonStr.startsWith('```json') ? jsonStr.replace(/```json\n|```/g, '') : jsonStr;
    const jsonResponse = JSON.parse(cleanedJsonStr);
    return jsonResponse;
  } catch (error) {
    console.error("Error verifying avatar:", error);
    return { isAvatar: false, reason: "Analysis failed." };
  }
}

export const generateSurprisePrompt = async (base64Images: {data: string, mimeType: string}[]): Promise<string> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
    const model = 'gemini-2.5-flash';
    const characterCount = base64Images.length;
    const prompt = `Based on the provided ${characterCount} character(s), generate a single, creative, and fun scene description prompt in 5-10 words. The prompt should be suitable for generating an image. Do not use quotes. Example: 'DJing at a huge concert'. Be imaginative!`;

    const imageParts = base64Images.map(image => ({
      inlineData: {
        data: image.data,
        mimeType: image.mimeType,
      },
    }));

    try {
        const response = await ai.models.generateContent({
            model,
            contents: { parts: [...imageParts, { text: prompt }] },
        });
        return response.text.trim().replace(/"/g, ''); // Remove quotes from response
    } catch(error) {
        console.error("Error generating surprise prompt:", error);
        return "on a beach in Bali"; // Return a default prompt on error
    }
};

export const enhancePrompt = async (base64Images: {data: string, mimeType: string}[], userPrompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
  const model = 'gemini-2.5-flash';
  const characterCount = base64Images.length;
  const characters = characterCount > 1 ? `these ${characterCount} characters` : 'this character';
  
  const prompt = `Based on the user's idea "${userPrompt}" and observing ${characters}, rewrite and enhance the prompt for an image generation model. Make it more vivid, descriptive, and imaginative. The final prompt should be a concise phrase (5-15 words) that captures a cool scene. Do not use quotes in the output. Keep the core concept of the user's prompt.`;

  const imageParts = base64Images.map(image => ({
    inlineData: {
      data: image.data,
      mimeType: image.mimeType,
    },
  }));
  
  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts: [...imageParts, { text: prompt }] },
    });
    return response.text.trim().replace(/"/g, '');
  } catch (error) {
    console.error("Error enhancing prompt:", error);
    throw new Error("Could not enhance the prompt.");
  }
};


export const editImage = async (base64Images: {data: string, mimeType: string}[], prompt: string, isHD: boolean): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
  try {
    const model = 'gemini-2.5-flash-image';
    
    const imageParts = base64Images.map(image => ({
      inlineData: {
        data: image.data,
        mimeType: image.mimeType,
      },
    }));

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          ...imageParts,
          {
            text: prompt,
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE],
        systemInstruction: getSceneGenerationInstruction(base64Images.length, isHD),
      },
    });

    if (
      response.candidates &&
      response.candidates[0] &&
      response.candidates[0].content &&
      response.candidates[0].content.parts
    ) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return part.inlineData.data;
        }
      }
    }
    return null;
  } catch (error) {
    console.error("Error calling Gemini API for image editing:", error);
    throw new Error("Failed to edit image due to an API error.");
  }
};
